const help = (pushname, prefix, temporizador, uptime, hr, tanggal, groupName, users, chatss, prema, checATM, useLevel, useXp, requireXp, patt, comandost ) => {
    return `
     ༻▬࣭ ▭࣭ ▬ ▭࣭ ★ ▬࣭ ▭࣭ ▬ ▭࣭༺
      Olá ${pushname}🧙‍♂️
     ༻▬࣭ ▭࣭ ▬ ▭࣭ ★ ▭࣭ ▬ ▭࣭ ▬࣭༺

🧙‍♂️ BOT 🧙‍♂️
≫ Prefix:「 ${prefix} 」
≫ Nome: Tiringa-BOT
≫ Versão 13.0
≫ Tempo online: ${temporizador(uptime)}
≫ Status: ON✅
≫ Horário: ${hr}
≫ Data: ${tanggal}
≫ Grupo:  ${groupName}
≫ Total de usuários: ${users} usuários
≫ Total de chats: ${chatss} chats
≫ Total de comandos: 152
≫ Total de comandos usados: ${comandost}
≫  API: https://api-exteam.herokuapp.com/
═══════════════

👨‍💻USUÁRIO👨‍💻
≫ Nome: ${pushname}
≫ Tipo de usuário: ${prema}
≫ Dinheiro: ${checATM}
≫ Level: ${useLevel}
≫ XP: ${useXp}/${requireXp}
≫ Patente: ${patt}
═══════════════
 ♻️NOVIDADES:

❧ menu +18 use =m18
═══════════════
✅  COMANDOS NOVOS:

❧ simi
❧ bugreport
❧ request
═══════════════
✔ REMOVIDOS:     

❧ nekonime
═══════════════
⚠️AVISO:

❧ v13 no github em breve...
═══════════════

═══════════════
════ 🧙‍♂️ INFORMAÇÕES 🧙‍♂️
╭╼╾╼╾╼╾╼╾╼╾╼╾╼╾
│•  ${prefix}info
│[  Informações do bot  ]
│•  ${prefix}criador
│[  Número do meu criador  ]
│•  ${prefix}ping
│[  Mostra meu tempo de resposta  ]
│•  ${prefix}infome
│[  Mostra algumas informações suas  ]
│•  ${prefix}infogp
│[  Mostra algumas informações do grupo  ]
│•  ${prefix}ts
│[  Lista os códigos de linguagem  ]
│•  ${prefix}bugreport
│[  Avise ao dono sobre algum bug  ]
│•  ${prefix}request
│[  Peça algo para ser adicionado ao bot  ]
╰╼╾╼╾╼╾╼╾╼╾╼╾╼╾
═════ ≪ •❈• ≫ ═════╝

═══════════════
════ 🔞 +18 🔞
╭╼╾╼╾╼╾╼╾╼╾╼╾╼╾
│•  ${prefix}m18
╰╼╾╼╾╼╾╼╾╼╾╼╾╼╾
═════ ≪ •❈• ≫ ═════╝

═══════════════
════ 👥 GRUPO 👥
╭╼╾╼╾╼╾╼╾╼╾╼╾╼╾
│•  ${prefix}listadmin
│[  Lista todos os administradores do grupo  ]
│•  ${prefix}online
│[  Lista todos os membros online  ]
│•  ${prefix}fecharg
│[  Fecha o grupo  ]
│•  ${prefix}abrirg
│[  Abre o grupo  ]
│•  ${prefix}promover
│[  Promove o alvo ao cargo de administrador  ]
│•  ${prefix}rebaixar
│[  Rabaixa o alvo a membro comum  ]
│•  ${prefix}setname
│[  Altera o nome do grupo  ]
│•  ${prefix}setdesk
│[  Altera a descrição do grupo  ]
│•  ${prefix}tagall
│[  Menciona todos os membros  ]
│•  ${prefix}linkgc
│[  link do grupo  ]
│•  ${prefix}leave
│[  O bot sai do grupo  ]
│•  ${prefix}notif
│[  Notifica todos os membros  ]
│•  ${prefix}welcome
│[  On/off welcome  ]
│•  ${prefix}delete (marque a mensagem)
│[  Apaga uma mensagem enviada pelo bot  ]
╰╼╾╼╾╼╾╼╾╼╾╼╾╼╾
═════ ≪ •❈• ≫ ═════╝

═══════════════
════ 🎥  MÍDIA 🎥
╭╼╾╼╾╼╾╼╾╼╾╼╾╼╾
│•  ${prefix}esquilo (marque um áudio)
│[  Efeito de áudio esquilo  ]
│•  ${prefix}slow (marque um áudio)
│[  Efeito de áudio lento  ]
│•  ${prefix}gemuk (marque um áudio)
│[  Efeito de áudio gigante  ]
│•  ${prefix}bass (marque um áudio)
│[  Aumenta o bass de uma música  ]
│•  ${prefix}earrape
│[  Deixa o áudio estourado  ]
│•  ${prefix}fast
│[  Deixa o áudio rápido  ]
╰╼╾╼╾╼╾╼╾╼╾╼╾╼╾
═════ ≪ •❈• ≫ ═════╝

═══════════════
════ 🏖 IMAGEM 🏖
╭╼╾╼╾╼╾╼╾╼╾╼╾╼╾
│•  ${prefix}gtav (Foto)
│[  Cria um banner do GTA V  ]
│•  ${prefix}wanted (Foto)
│[  Cria um banner estilo "WANTED"  ]
│•  ${prefix}drawing (Foto)
│[  Cria uma imagem estilo desenho  ]
│•  ${prefix}8bit (Texto)
│[  Cria uma imagem no estilo 8bit  ]
│•  ${prefix}lovepaper (Texto)
│[  Cria uma imagem no estilo lovepaper  ]
│•  ${prefix}narutobanner (Texto)
│[  Cria um banner de Naruto  ]
│•  ${prefix}romancetext (Texto)
│[  Cria uma imagem no estilo romancetext  ]
│•  ${prefix}shadowtext (Texto)
│[  Cria uma imagem no estilo shadowtext  ]
│•  ${prefix}tiktokeffect (Texto)
│[  Cria uma imagem no estilo Tik Tok  ]
│•  ${prefix}neon (Texto)
│[  Cria uma imagem no estilo neon  ]
│•  ${prefix}hpotter (Texto)
│[  Cria uma imagem no estilo Harry Potter  ]
│•  ${prefix}gaming (Texto)
│[  Cria uma imagem no estilo gaming  ]
│•  ${prefix}bneon (Texto)
│[  Cria uma imagem no estilo neon  ]
│•  ${prefix}matrix (Texto)
│[  Cria uma imagem no estilo Matrix  ]
│•  ${prefix}breakwall (Texto)
│[  Cria uma imagem no estilo breakwall  ]
│•  ${prefix}dropwater (Texto)
│[  Cria uma imagem no estilo dropwater  ]
│•  ${prefix}wolflogo (Texto)
│[  Cria uma imagem no estilo wolflogo  ]
│•  ${prefix}tfire (Texto)
│[  Cria uma imagem no estilo tfire  ]
│•  ${prefix}sandw (Texto)
│[  Cria uma imagem no estilo sandw  ]
│•  ${prefix}firofiro (Texto)
│[  Cria uma imagem no estilo free fire  ]
│•  ${prefix}text3d (Texto)
│[  Cria uma imagem no estilo text3d  ]
│•  ${prefix}text3d2 (Texto)
│[  Cria uma imagem no estilo text3d2  ]
│•  ${prefix}phlogo (Texto)
│[  Cria uma imagem no estilo PornHub  ]
│•  ${prefix}bpmek (Texto)
│[  Cria uma imagem no estilo BlackPmek  ]
│•  ${prefix}folhas (Texto)
│[  Cria uma imagem com texto entre folhas  ]
│•  ${prefix}tlight (Texto)
│[  Cria uma imagem no estilo tlight  ]
│•  ${prefix}sparkling (Texto)
│[  Cria uma imagem no estilo sparkling  ]
│•  ${prefix}neve (Texto)
│[  Cria uma imagem com texto na neve  ]
│•  ${prefix}crismes (Texto)
│[  Cria uma imagem no estilo crismes  ]
│•  ${prefix}retro (Texto)
│[  Cria uma imagem no estilo retro  ]
│•  ${prefix}watercolor
│[  Cria uma imagem no estilo watercolor  ]
│•  ${prefix}pubglogo (Texto)
│[  Cria uma imagem no estilo pubg  ]
│•  ${prefix}bf4 (Texto)
│[  Cria uma imagem no estilo bf4  ]
│•  ${prefix}cslogo (Texto)
│[  Cria uma imagem no estilo CS  ]
│•  ${prefix}lithgtext (Texto)
│[  Cria uma imagem no estilo lithgtext  ]
│•  ${prefix}silktext (Texto)
│[  Cria uma imagem no estilo silktext  ]
│•  ${prefix}flametext (Texto)
│[  Cria uma imagem no estilo flametext  ]
│•  ${prefix}crosslogo (Texto)
│[  Cria uma imagem no estilo crosslogo  ]
│•  ${prefix}glowtext (Texto)
│[  Cria uma imagem no estilo glowtext  ]
│•  ${prefix}triggered
│[  Cria um sticker no estilo triggered  ]
│•  ${prefix}wasted
│[  Cria imagem no estilo wasted  ]
╰╼╾╼╾╼╾╼╾╼╾╼╾╼╾
═════ ≪ •❈• ≫ ═════╝

═══════════════
════ 🎲 DIVERSÃO 🎲
╭╼╾╼╾╼╾╼╾╼╾╼╾╼╾
│•  ${prefix}simi
│[  I.A  ]
│•  ${prefix}shitpost
│[  Imagem aleatória shitpost br  ]
│•  ${prefix}nomeninja (texto)
│[  Cria um nome ninja  ]
│•  ${prefix}tagme
│[  Te menciona  ]
│•  ${prefix}dado
│[  Sticker de dado aleatório  ]
│•  ${prefix}ppt (pedra, papel ou tesoura)
│[  Jogue pedra, papel e tesoura com o bot  ]
│•  ${prefix}sn
│[  Lhe diz sim ou não para uma pergunta  ]
│•  ${prefix}gado
│[  Lhe diz seu nível de gado  ]
│•  ${prefix}chance
│[  Lhe diz a chance de algo  ]
│•  ${prefix}pau
│[  Lhe diz o tamanho do seu brinquedo  ]
│•  ${prefix}gay
│[  Lhe diz o quanto gay você é  ]
│•  ${prefix}slot
│[  Caça níqueis  ]
│•  ${prefix}caracoroa
│[  Caracoroa  ]
│•  ${prefix}level
│[  Mostra seu level atual  ]
│•  ${prefix}roleta
│[  Roleta russa  ]
│•  ${prefix}amongus
│[  "Expulsa" alguém da nave  ]
│•  ${prefix}ttt
│[  Jogo da velha by: Resen  ]
│•  ${prefix}omais
│[  Sorteia alguém para "o mais"  ]
│•  ${prefix}top5
│[  Menciona 5 membros do grupo  ]
╰╼╾╼╾╼╾╼╾╼╾╼╾╼╾
═════ ≪ •❈• ≫ ═════╝

═══════════════
════ 💮 ANIME 💮
╭╼╾╼╾╼╾╼╾╼╾╼╾╼╾
│•  ${prefix}anime
│[  Imagem de anime aleatória  ]
│•  ${prefix}loli
│[  Imagem de loli aleatória  ]
│•  ${prefix}neko
│[  Imagem de neko aleatória  ]
│•  ${prefix}nezuko
│[  Imagem aleatória da Nezuko  ]
╰╼╾╼╾╼╾╼╾╼╾╼╾╼╾
═════ ≪ •❈• ≫ ═════╝

═══════════════
════ 🔧 FERRAMENTAS 🔧
╭╼╾╼╾╼╾╼╾╼╾╼╾╼╾
│•  ${prefix}st 
│[  Cria um sticker em 512x512  ]
│•  ${prefix}sticker
│[  Cria um sticker  ]
│•  ${prefix}toimg
│[  Converte sticker em imagem  ]
│•  ${prefix}tomp3
│[  Converte vídeo em áudio  ]
│•  ${prefix}Img (Texto)
│[  Busca uma imagem relacionada  ]
│•  ${prefix}play (título)
│[  Baixa o áudio de um vídeo no YouTube  ]
│•  ${prefix}tts (língua) (texto)
│[  Texto para áudio(voz do google)  ]
│•  ${prefix}timer (tempo)
│[  Um timer  ]
│•  ${prefix}wame
│[  Mostra seu link wa.me  ]
│•  ${prefix}ocr
│[  Captura o texto de uma imagem  ]
│•  ${prefix}cep (cep)
│[  Lista algumas informações do cep  ]
│•  ${prefix}cartão 
│[  Gera uma cartão de crédito fake  ]
│•  ${prefix}contar
│[  Conta a quantidade de caracteres  ]
│•  ${prefix}clima
│[  Mostra o clima atual  ]
│•  ${prefix}togif
│[  Converte sticker em gif  ]
│•  ${prefix}gimage
│[  Busca imagem no google  ]
╰╼╾╼╾╼╾╼╾╼╾╼╾╼╾
═════ ≪ •❈• ≫ ═════╝

═══════════════
════ 📲 DOWNLOADER 📲
╭╼╾╼╾╼╾╼╾╼╾╼╾╼╾
│•  ${prefix}ytmp3 (link)
│[  Baixa audio do youtube  ]
│•  ${prefix}ytmp4 (link)
│[  Baixa video do youtube  ]
╰╼╾╼╾╼╾╼╾╼╾╼╾╼╾
═════ ≪ •❈• ≫ ═════╝

═══════════════
════ 🕴 CRIADOR 🕴
╭╼╾╼╾╼╾╼╾╼╾╼╾╼╾
│•  ${prefix}clone
│[  Copia a foto de perfil do alvo  ]
│•  ${prefix}block
│[  Bloqueia o alvo  ]
│•  ${prefix}unblock
│[  Remove o block do alvo  ]
│•  ${prefix}blocklist
│[  Lista dos usuários bloqueados  ]
│•  ${prefix}ban
│[  Adciona um usuário a lista de banidos  ]
│•  ${prefix}unban
│[  Remove o usuário da lista de banidos  ]
│•  ${prefix}addprem
│[  Adciona um usuário a lista premium  ]
│•  ${prefix}dellprem
│[  Remove o usuário da lista premium  ]
╰╼╾╼╾╼╾╼╾╼╾╼╾╼╾
═════ ≪ •❈• ≫ ═════╝`
}
exports.help = help

const m18 = (pushname, prefix) => {
    return `    
     ༻▬࣭ ▭࣭ ▬ ▭࣭ ★ ▬࣭ ▭࣭ ▬ ▭࣭༺
      Olá ${pushname}🧙‍♂️
     ༻▬࣭ ▭࣭ ▬ ▭࣭ ★ ▭࣭ ▬ ▭࣭ ▬࣭༺

☀️　　🌎　°　　🌓　•　　.°•　　　🚀　　
　　　★　*　　🛸　　　°　🚀　　　　°·　
.　　　•　°★　•
Caso algum comando esteja errado avise o
wa.me/+557499510904
▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄
╔════ 🔞 +18 🔞
║╭╼╾╼╾╼╾╼╾╼╾╼╾╼╾
║│•  ${prefix}holo
║│
║│•  ${prefix}solo
║│
║│•  ${prefix}ero
║│
║│•  ${prefix}spank
║│
║│•  ${prefix}erofeet
║│
║│•  ${prefix}feet
║│
║│•  ${prefix}holoero
║│
║│•  ${prefix}classic
║│
║│•  ${prefix}cum
║│
║│•  ${prefix}eroyuri
║│
║│•  ${prefix}eron
║│
║│•  ${prefix}pwankg
║│
║│•  ${prefix}anal
║│
║│•  ${prefix}lewdkemo
║│
║│•  ${prefix}lewd
║│
║│•  ${prefix}solog
║│
║│•  ${prefix}lewdk
║│
║│•  ${prefix}hentai
║│
║│•  ${prefix}blowjob
║│
║│•  ${prefix}hololewd
║│
║│•  ${prefix}trap
║│
║│•  ${prefix}les
║│
║│•  ${prefix}smallboobs
║│
║│•  ${prefix}futanari
║│
║│•  ${prefix}femdom
║│
║│•  ${prefix}feed
║│
║│•  ${prefix}erok
║│
║│•  ${prefix}feetg
║│
║│•  ${prefix}erokemo
║│
║│•  ${prefix}boobs
║│
║│•  ${prefix}nsfwloli
║│
║│•  ${prefix}pussy
║│
║│•  ${prefix}tits 1, 2, 3... 9
║│
║╰╼╾╼╾╼╾╼╾╼╾╼╾╼╾
╚═════ ≪ •❈• ≫ ═════╝`
}
exports.m18 = m18




